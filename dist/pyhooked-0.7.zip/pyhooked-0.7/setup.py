from distutils.core import setup
setup(
name='pyhooked',
packages=['pyhooked'],
version='0.7',
description='Pure Python hotkey hook, with thanks to pyHook and pyhk',
author='Ethan Smith',
author_email='mr.smittye@gmail.com',
url='https://github.com/IronManMark20/hooked',
download_url="https://github.com/IronManMark20/hooked/tarball/0.7",
keywords = ['hotkey','shortcut','windows','keyboard','hooks'],
classifiers = [],
)